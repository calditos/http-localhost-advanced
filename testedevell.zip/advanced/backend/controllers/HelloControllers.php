<?php

namespace app\controllers;

use Yii;
use app\models\Usuario;
use app\models\cadastroModel;
use yii\base\Controller;
use yii\data\Pagination;

class TesteController extends Controller
   {
        public function actionFormularioClient(){...}

        public function actionPessoas()
        {
        	$query = Usuarios::find();

        	$pagination = new Pagination([
        	  'defaultPageSize' => 3
        	  'totalCount' => $query->count()
        	]} 


        	$Usuarios = $query->orderBy('nome')
                             ->offset($pagination->offset)
                             ->limit($pagination->limit)
                             ->all();

        	return $this->render('Usuarios',[
                'Usuarios' => $Usuarios,
                'pagination' => $pagination,
             ]);
        }
   }
