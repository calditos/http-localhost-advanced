<?php
use \yii\widgets\LinkPager;

<h1>Usuarios</h1>
<hr>


<ul>
    
    <?php foreach($Usuario as $Usuarios) : ?>
       <li>
         <?= $Usuario->nome.''.$Usuario->email ?><br />
         <small><?= $Usuario->estado.''.$Usuario->cidade ?></small>
       </li>
    <?php endforeach ?>
</ul>
<?= LinkPager::widget(['pagination '=>$pagination])